#pragma once

const int NUM_FUNCTIONS = 5;
const char LOWEST_CHOICE_MENU = '0';
const char HIGHEST_CHOICE_MENU = '6';
const char LOWER_CASE_EXIT_PROGRAM = 'x';
const char UPPER_CASE_EXIT_PROGRAM = 'X';
